# 08-Breakout
This is a game of breakout! Player's will be able to bounce a ball off of a moving paddle that follows their mouse. Any brick the ball touches will break and points will be scored. If the ball falls off of the screen 3 times then the game is lost.
